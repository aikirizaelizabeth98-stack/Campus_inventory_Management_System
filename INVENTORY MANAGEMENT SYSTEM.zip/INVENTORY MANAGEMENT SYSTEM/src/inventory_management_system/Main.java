package inventory_management_system;

public class Main {

	public static void main(String[] args) {
		//FIVE(5) OBJECTS CREATED FROMOUR CLASS
Product product1 = new Product();
Product product2 = new Product();
Product product3 = new Product();
Product product4 = new Product();
Product product5 = new Product();

	System.out.printf("\n ***INVENTORY MANAGEMENT SYSTEM CALCULATOR***\n");
	
// PRODUCT CATEGORY 1
product1.setProductID("P01");
product1.setProductName("Exercise Books");
product1.setProductCategory("Stationery");
product1.setUnitPrice(5000.0);
product1.setQuantityInStock(100);


//PRODUCT CATEGORY 2
product2.setProductID("P02");
product2.setProductName("Pens");
product2.setProductCategory("Stationery");
product2.setUnitPrice(1000.0);
product2.setQuantityInStock(200);


//PRODUCT CATEGORY 3
product3.setProductID("P03");
product3.setProductName("Printing Papers");
product3.setProductCategory("Stationery");
product3.setUnitPrice(20000.0);
product3.setQuantityInStock(400);


//PRODUCT CATEGORY 4
product4.setProductID("P04");
product4.setProductName("Flash Disks");
product4.setProductCategory("Electronics");
product4.setUnitPrice(30000.0);
product4.setQuantityInStock(250);


//PRODUCT CATEGORY 5
product5.setProductID("P05");
product5.setProductName("Calculators");
product5.setProductCategory("Stationery");
product5.setUnitPrice(50000.0);
product5.setQuantityInStock(50);

//QUESTION 4: DISPLAYING USING GETTER METHODS

System.out.printf("\n --PRODUCT 1-- \n ");
//Product 1 Getter
System.out.println("PRODUCT ID: "+product1.getProductID ());
System.out.println("PRODUCT NAME: "+product1.getProductName());
System.out.println("PRODUCT CATEGORY: " +product1.getProductCategory());
System.out.println("UNITT PRICE "+product1.getUnitPrice());
System.out.println("QUANTITY IN STOCK " + product1.getQuantityInStock());

System.out.printf("\n --PRODUCT 2-- \n ");
//Product 2 Getter
System.out.println("PRODUCT ID: " + product2.getProductID ());
System.out.println("PRODUCT NAME: " + product2.getProductName());
System.out.println("PRODUCT CATEGORY " +product2.getProductCategory());
System.out.println("QUANTITY IN STOCK: " + product2.getQuantityInStock());
System.out.println("UNIT PRICE: " + product2.getUnitPrice());

System.out.printf("\n --PRODUCT 3-- \n ");
//Product 3 Getter
System.out.println("PRODUCT ID: "+ product3.getProductID ());
System.out.println("PRODUCT NAME: "+product3.getProductName());
System.out.println("PRODUCT CATEGORY "+product3.getProductCategory());
System.out.println("PRODUCT QUANTITY " + product3.getQuantityInStock());
System.out.println("UNIT PRICE " + product3.getUnitPrice());

System.out.printf("\n --PRODUCT 4-- \n ");
//Product 4 Getter
System.out.println("PRODUCT ID "+product4.getProductID ());
System.out.println("PRODUCT NAME: " + product4.getProductName());
System.out.println("PRODUCT CATEGORY: "+product4.getProductCategory());
System.out.println("PRODUCT QUANTITY: " + product4.getQuantityInStock());
System.out.println("UNIT PRICE: "+ product4.getUnitPrice());

System.out.printf("\n --PRODUCT 5-- \n ");
//Product 5 Getter
System.out.println("PRODUCT ID: "+ product5.getProductID ());
System.out.println("PRODUCT NAME: " + product5.getProductName());
System.out.println("PRODUCT CATEGORY " +product5.getProductCategory());
System.out.println("PRODUCT QUANTITY: " + product5.getQuantityInStock());
System.out.println(product5.getUnitPrice());




//PRICE UPDATE OF PRODUCT 1
System.out.printf("\n **UPDATED PRODUCT 1 PRICE**\n");
product1.setUnitPrice(7000.0);
System.out.println(product1.getUnitPrice());


//STOCK QUANTITY UPDATE OF PRODUCT 2
//PRICE UPDATE OF PRODUCT 2
System.out.printf("\n **UPDATED PRODUCT 2 QUANTITY IN STOCK**\n");
product2.setQuantityInStock(800);
System.out.println(product2.getQuantityInStock());


//DEMONSTRATION WHEN A NEGATIVE PRICE VALUE IS SUBMITTED.
System.out.printf("\n ---NEGATIVE VALUE ERROR--- \n");
product3.setUnitPrice(-2000.0);



		
	}

}