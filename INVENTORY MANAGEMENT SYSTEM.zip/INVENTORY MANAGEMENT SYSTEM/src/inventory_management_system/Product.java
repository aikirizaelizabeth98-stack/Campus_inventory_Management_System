
package inventory_management_system;

public class Product {

	//PRODUCT ATTRIBUTES.
	private String productID;
	private String	productName;
	private String productCategory;
	private double unitPrice;
	private int quantityInStock;
	
	//GETTERS OR ACCESSORS
	public String getProductName(){
		return productName;
	}
	
	public String getProductCategory(){
		return productCategory;
	}
	
	
	public double getUnitPrice(){
		return unitPrice;
	}
	
	
	public String getProductID(){
		return productID;
	}
	
	public int getQuantityInStock(){
		return quantityInStock;
	}
		
	//MUTATORS OR SETTERS
	public void setProductID (String productID ){
		this.productID = productID;
		
	}	
	
	public void setProductName (String productName){
		this.productName = productName;
		
	}	
	
	public void setProductCategory(String productCategory){
		this.productCategory = productCategory;
		
	}	
	//UNIT PRICE SETTERS WITH VALIDATION RULE FOR NEGATIVE VALUE
	
	public void setUnitPrice (double unitPrice){
		if(unitPrice < 0)
		{
			System.out.println("Invalid Amount");
		} else {
			this.unitPrice = unitPrice;
			}
		
		
	}	
	
	//STOCK QUANTITY SETTERS WITH VALIDATION RULE FOR THE NEGATIVE VALUES.
	
	public void setQuantityInStock (int quantityInStock){
		if(quantityInStock < 0) {
			System.out.println("Quantity can't be a Negative");
		}else
		
		this.quantityInStock = quantityInStock;}
	}
